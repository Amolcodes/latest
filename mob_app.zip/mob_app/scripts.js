let taskList = [];

function addTask() {
    // Get values from input fields
    let assignedBy = document.getElementById("assignedBy").value;
    let task = document.getElementById("task").value;
    let assignedTo = document.getElementById("assignedTo").value;
    let date = new Date().toISOString().split('T')[0];

    // Add task to the task list
    taskList.push({
        assignedBy: assignedBy,
        task: task,
        assignedTo: assignedTo,
        status: 'pending',
        completedDate: '',
        date: date
    });

    // Update Task Manager tab with the new task
    displayTasks();

    // Switch to Task Manager tab
    document.getElementById("taskAssigner").style.display = "none";
    document.getElementById("taskManager").style.display = "block";
}

function displayTasks() {
    let taskTableBody = document.getElementById("taskTableBody");
    taskTableBody.innerHTML = '';

    taskList.forEach((task, index) => {
        let row = taskTableBody.insertRow();
        row.innerHTML = `
            <td>${task.assignedBy}</td>
            <td>${task.task}</td>
            <td>${task.assignedTo}</td>
            <td>
                <label><input type="radio" name="status${index}" ${task.status === 'completed' ? 'checked' : ''} onchange="updateStatus(${index}, 'completed')"> Completed</label>
                <label><input type="radio" name="status${index}" ${task.status === 'pending' ? 'checked' : ''} onchange="updateStatus(${index}, 'pending')"> Pending</label>
            </td>
            <td>${task.completedDate || ''}</td>
            <td>${task.date}</td>
        `;
    });
}

function updateStatus(index, status) {
    if (status === 'completed') {
        taskList[index].status = 'completed';
        taskList[index].completedDate = new Date().toISOString().split('T')[0]; // Set completed date
    } else {
        taskList[index].status = 'pending';
        taskList[index].completedDate = ''; // Reset completed date
    }
    displayTasks(); // Update the display after changing the status
}
